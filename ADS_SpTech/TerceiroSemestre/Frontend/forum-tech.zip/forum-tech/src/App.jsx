import { RootProvider } from './provedores/RootProvider'

function App() {

  return <RootProvider/>
}

export default App
