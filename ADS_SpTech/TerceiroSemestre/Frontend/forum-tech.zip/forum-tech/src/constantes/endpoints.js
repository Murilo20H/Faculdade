export const ENDPOINTS = {
  LOGIN: '/api/usuarios/login',
  POSTAGENS: '/api/postagens',
  SIGNUP:'/api/usuarios'
}
