export const ROUTERS = {
  HOME: '/',
  LOGIN: '/login',
  SIGNUP: '/cadastrar-se',
  POSTS:'/postagens',
  CREATE_POST:'/postagens/criar',
  EDIT_POST:'/postagens/editar',
}
