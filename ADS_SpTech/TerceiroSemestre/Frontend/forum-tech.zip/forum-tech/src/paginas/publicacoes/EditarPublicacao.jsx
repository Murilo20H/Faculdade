import { FormPublicacao } from "./componentes/FormPublicacao";

export function EditarPublicacao() {

    return (
        <FormPublicacao/>
    )
}